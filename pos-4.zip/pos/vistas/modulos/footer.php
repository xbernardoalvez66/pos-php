<footer class="main-footer">
	<strong>Copyright &copy; 2020 <a href="google.com" target="_blank">Bernardo Alvez</a>.
   Todos los derechos reservados

	</strong>
</footer>