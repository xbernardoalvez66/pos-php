 <?php

  class ControladorVentas{

/*=========================
      MOSTRAR VENTAS
      ===============*/
       static public function ctrMostrarVentas($item, $valor)
      {
     
        $tabla = "ventas";
        $respuesta = ModelosVentas::MdlMostrarVentas($tabla, $item, $valor);
     
        return $respuesta;
      }



  }                      

 ?>