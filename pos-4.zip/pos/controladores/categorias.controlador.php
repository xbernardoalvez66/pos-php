 <?php
class ControladorCategorias{

	/*=============================================
	=      CREAR CATEGORIAS =
	=============================================*/
 static public function ctrCrearCategoria(){

		if(isset($_POST["nuevaCategoria"])){

			
           if ( preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["nuevaCategoria"])){

            	$tabla ="categorias";

            	$datos = $_POST["nuevaCategoria"];

            	$respuesta = ModelosCategorias::mdlIngresarCategoria($tabla, $datos);

            	if($respuesta == "ok"){

            		echo '<script>
                    Swal.fire({
                    icon:"success",
                    title:"La categoria ha sido agregada correctamente",
                    showConfirmButton:true,
                    confirmButtonText:"Cerrar",
                    preConfirm: false
         
                    }).then((result)=>{
                      
                     if(result.value){
                      window.location = "categorias";
                     }
         
                      });
           
                </script>';
            	}

            }else{

            	 echo '<script>
         
                  Swal.fire({
                    icon:"error",
                    title:"!La categoria no puede ir vacia o llevar caracteres especiales!",
                    showConfirmButton:true,
                    confirmButtonText:"Cerrar",
                    preConfirm: false
         
                    }).then((result)=>{
                      
                     if(result.value){
                      window.location = "categorias";
                     }
         
                      });
         
                </script>';
            }
		}
	}
	/*=============================================
	=      MOSTRAR CATEGORIAS =
	=============================================*/
	static public function ctrMostrarCategorias($item,$valor){

		$tabla = "categorias";

		$respuesta = ModelosCategorias::mdlMostrarCategorias($tabla, $item, $valor);

		return $respuesta;


	} 
	/*=============================================
	=      EDITAR CATEGORIAS =
	=============================================*/
 static public function ctrEditarCategoria(){

		if(isset($_POST["editarCategoria"])){

			
           if ( preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["editarCategoria"])){

            	$tabla ="categorias";

            	$datos = array("categoria"=>$_POST["editarCategoria"],"id"=>$_POST["idCategoria"]);

            	$respuesta = ModelosCategorias::mdlEditarCategoria($tabla, $datos);

            	if($respuesta == "ok"){

            		echo '<script>
                    Swal.fire({
                    icon:"success",
                    title:"La categoria ha sido editada correctamente",
                    showConfirmButton:true,
                    confirmButtonText:"Cerrar",
                    preConfirm: false
         
                    }).then((result)=>{
                      
                     if(result.value){
                      window.location = "categorias";
                     }
         
                      });
           
                </script>';
            	}

            }else{

            	 echo '<script>
         
                  Swal.fire({
                    icon:"error",
                    title:"!La categoria no puede ir vacia o llevar caracteres especiales!",
                    showConfirmButton:true,
                    confirmButtonText:"Cerrar",
                    preConfirm: false
         
                    }).then((result)=>{
                      
                     if(result.value){
                      window.location = "categorias";
                     }
         
                      });
         
                </script>';
            }
		}
	}

	/*=============================================
	=      BORRAR CATEGORIAS =
	=============================================*/
static public function ctrBorrarCategoria(){

	if(isset($_GET["idCategoria"])){
     
     $tabla ="categorias";
     $datos = $_GET["idCategoria"];

     $respuesta = ModelosCategorias::mdlBorrarCategoria($tabla, $datos);

     if($respuesta == "ok"){
      echo '<script>
                    Swal.fire({
                    icon:"success",
                    title:"La categoria ha sido borrada correctamente",
                    showConfirmButton:true,
                    confirmButtonText:"Cerrar",
                    preConfirm: false
         
                    }).then((result)=>{
                      
                     if(result.value){
                      window.location = "categorias";
                     }
         
                      });
           
                </script>';

     }

	}
}
	
}
                        

 ?>