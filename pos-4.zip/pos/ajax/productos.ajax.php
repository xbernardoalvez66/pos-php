<?php

require_once "../controladores/productos.controlador.php";
require_once "../modelos/productos.modelo.php";




class AjaxProductos
{
  /*=============================================
= GENERAR CODIGO A PARTIR ID CATEGORIA  =
=============================================*/

  public $idCategoria; 

  public function ajaxCrearCodigoProducto(){

  	$item = "id_categoria";
  	$valor = $this->idCategoria;



  	$respuesta = ControladorProductos::ctrMostrarProductos($item, $valor);


  	echo json_encode($respuesta);


  }
/*=============================================
=            EDITAR PRODUCTO           =
=============================================*/
 public $idProducto;

 public $traerProductos;

 public $nombreProducto;

 public function ajaxEditarProducto(){

  if($this->traerProductos == "ok"){

     $item = null;
    $valor = null;

    $respuesta = ControladorProductos::ctrMostrarProductos($item, $valor);


    echo json_encode($respuesta);


  } else if($this-> nombreProducto != ""){

    $item = "descripcion";
    $valor = $this->nombreProducto;

    $respuesta = ControladorProductos::ctrMostrarProductos($item, $valor);


    echo json_encode($respuesta);




 } else{

    $item = "id";
  	$valor = $this->idProducto;

  	$respuesta = ControladorProductos::ctrMostrarProductos($item, $valor);


  	echo json_encode($respuesta);

    }


 }






}
  /*=============================================
= GENERAR CODIGO A PARTIR ID CATEGORIA  =
=============================================*/
if(isset($_POST["idCategoria"])){

	$codigoPorducto = new AjaxProductos();
	$codigoPorducto -> idCategoria = $_POST["idCategoria"];
	$codigoPorducto -> ajaxCrearCodigoProducto();


}
/*=============================================
=            EDITAR PRODUCTO           =
=============================================*/
if(isset($_POST["idProducto"])){

	$editarPorducto = new AjaxProductos();
	$editarPorducto -> idProducto  = $_POST["idProducto"];
	$editarPorducto -> ajaxEditarProducto();


}

/*=============================================
=            TRAER PRODUCTO           =
=============================================*/
if(isset($_POST["traerProductos"])){

  $traerProductos = new AjaxProductos();
  $traerProductos -> traerProductos  = $_POST["traerProductos"];
  $traerProductos -> ajaxEditarProducto();


}

/*=============================================
=            TRAER PRODUCTO           =
=============================================*/
if(isset($_POST["nombreProducto"])){

  $traerProductos = new AjaxProductos();
  $traerProductos -> nombreProducto  = $_POST["nombreProducto"];
  $traerProductos -> ajaxEditarProducto();


}



?>